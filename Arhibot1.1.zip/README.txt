EN:
Arhibot-malware
Version: 1.1
Or: Arhibot 1.1

---- Information ----
Creator: Super Tank
Written in: C#
Type: GDI malware
Needed .NET Framework: .Net Framework 4.0
---------------------

RUS:
Arhibot-malware
Версия: 1.1
Или же: Arhibot 1.1

---- Информация ----
Создатель: Super Tank
Написано на: C#
Тип: GDI malware
Необходимая версия .Net Framework: .Net Framework 4.0
---------------------

Youtube channel creator: https://www.youtube.com/@BelugaHeckerOfficial
